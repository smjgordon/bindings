I have included a prebuilt FreeType.dll for the windows 
version of the dynamic linker.  While using this one is not
strictly necessary, it will prove to be the most 
accomodating to the FreeType user.

It was custom compiled using the Digitalmars C compiler for
optimal compatibility with the D language.
  
Since many of the FreeType dll distributions available on the
internet do not include the complete FreeType function list, I 
decided it would be practical to include this one just in case. 
By default, I compiled it with all FreeType modules enabled.

The linux shared library appears to include all modules and
functions by default, so doing the same for that platform was
not necessary.

-JJR 
