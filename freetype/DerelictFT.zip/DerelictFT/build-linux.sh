#!/bin/sh

CLEANUP=0

if [ -f "build-config.sh" ]; then
	`sh build-config.sh $@`
else
	CLEANUP=1
	cd ..
	if [ -f "build-config.sh" ]; then
		`sh build-config.sh $@`
	else
		echo "build-config.sh not found!"
	fi
fi

BUILD_TYPE=`cat build-args`
`$BUILD_TYPE DerelictFT/derelict/freetype/ft.d -XDerelictUtil/derelict/util \
	-IDerelictFT -Tlib/libderelictFT.a`

if [ $CLEANUP -eq 1 ]; then
	rm -f build-args
fi
