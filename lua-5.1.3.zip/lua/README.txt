Author: Matthias Walter

* Lua bindings for the D programming language
* Wrappers for states and buffers
* Wrappers for all native lua datatypes
* Exception safety
* Mixins for registering D methods and classes to lua

